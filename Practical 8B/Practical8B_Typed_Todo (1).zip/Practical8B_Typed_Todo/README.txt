PRACTICAL 8B - REACT + TYPESCRIPT TYPED TO-DO LIST

How to run:
1. Install Node.js if it is not already installed.
2. Extract this ZIP and open the Practical8B_Typed_Todo folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
   npm install
   npm run dev
5. Open the localhost URL shown in the terminal.

Features:
- Adds a task
- Marks a task as complete (strikethrough)
- Deletes a task
- Does not add blank tasks

Main concepts:
- Task interface is reused from src/types.ts.
- TaskInput and TaskItem are functional components.
- Props are typed using interfaces.
- useState<string> stores the input.
- useState<Task[]> stores the task list.
